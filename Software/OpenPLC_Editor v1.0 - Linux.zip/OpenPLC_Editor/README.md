# OpenPLC Editor
OpenPLC Editor - IDE capable of creating programs for the OpenPLC Runtime

# To Install:
run ./install.sh on terminal.

# To Run:
Find "OpenPLC Editor" on your applications menu and launch it
