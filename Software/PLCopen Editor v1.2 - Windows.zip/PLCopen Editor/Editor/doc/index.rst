.. Beremiz documentation master file

Beremiz's documentation
=======================

Contents:

.. toctree::
   :maxdepth: 2

   overview
   manual/index
   standards

