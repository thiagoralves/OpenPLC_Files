# superseeded by test_numbers.py
import unittest

if __name__ == '__main__':
    unittest.main()
